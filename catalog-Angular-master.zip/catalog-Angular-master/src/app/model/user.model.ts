export interface AppUser {
  userId:String;
  username : string;
  password: string;
  roles : String[];
}
